<?php
/**
 * Plugin Name: Notification : Yoast SEO
 * Description: Yoast SEO merge tags for post triggers
 * Author: Jean-Paul Horn
 * Version: 1.0.0
 * License: GPL2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

defined( 'ABSPATH' ) || exit;

add_action( 'notification/trigger/registered', function( $trigger ) {

	if ( ! preg_match( '/wordpress\/(.*)\/(updated|trashed|published|drafted|added|pending)/', $trigger->get_slug() ) ) {
		return;
	}

	// Add your Tag.
	// Pay attention to the Tag type you are defining.
	// If you want to output an HTML, use HtmlTag instead.
	$trigger->add_merge_tag( new BracketSpace\Notification\Defaults\MergeTag\StringTag( [
		'slug'     => 'yoast_title',
		'name'     => __( 'Yoast SEO: Title', 'textdomain' ),
		'resolver' => function( $trigger ) {
			return get_post_meta( $trigger->post->ID, '_yoast_wpseo_title', true );
		},
	] ) );

	$trigger->add_merge_tag( new BracketSpace\Notification\Defaults\MergeTag\StringTag( [
		'slug'     => 'yoast_desc',
		'name'     => __( 'Yoast SEO: Description', 'textdomain' ),
		'resolver' => function( $trigger ) {
			return get_post_meta( $trigger->post->ID, '_yoast_wpseo_metadesc', true );
		},
	] ) );

	$trigger->add_merge_tag( new BracketSpace\Notification\Defaults\MergeTag\StringTag( [
		'slug'     => 'yoast_focuskw',
		'name'     => __( 'Yoast SEO: Focus keyword', 'textdomain' ),
		'resolver' => function( $trigger ) {
			return get_post_meta( $trigger->post->ID, '_yoast_wpseo_focuskw', true );
		},
	] ) );

	$trigger->add_merge_tag( new BracketSpace\Notification\Defaults\MergeTag\IntegerTag( [
		'slug'     => 'yoast_score',
		'name'     => __( 'Yoast SEO: Content score', 'textdomain' ),
		'resolver' => function( $trigger ) {
			return get_post_meta( $trigger->post->ID, '_yoast_wpseo_content_score', true );
		},
	] ) );

} );
